export interface Adventure {
  id?: number;
  name: string;
  levelRequired: number;
  winXP: number;
  winGold: number;
}
