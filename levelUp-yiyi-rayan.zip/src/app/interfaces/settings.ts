export interface Settings {
  xpFirstLevel: number;
  xpRatioByLevel: number;
  maxLevel: number;
}
