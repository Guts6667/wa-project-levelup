import { Component } from '@angular/core';

@Component({
  selector: 'app-adventure-item',
  templateUrl: './adventure-item.component.html',
  styleUrls: ['./adventure-item.component.scss']
})
export class AdventureItemComponent {

}
