export interface User {
  id: number;
  name: string;
  xp: number;
  gold: number;
}
