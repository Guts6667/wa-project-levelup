import { Component } from '@angular/core';

@Component({
  selector: 'app-donjons',
  templateUrl: './donjons.component.html',
  styleUrls: ['./donjons.component.scss']
})
export class DonjonsComponent {

}
